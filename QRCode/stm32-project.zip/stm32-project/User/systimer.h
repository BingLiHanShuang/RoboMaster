#include "stm32f10x_tim.h"
#include "stm32f10x_exti.h"
#include "stm32f10x.h"
void TIMER_cfg();
void NVIC_cfg();