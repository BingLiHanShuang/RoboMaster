//
// Created by wzq on 26/03/2017.
//

#ifndef STM32_PROTOCOL_CONFIG_H
#define STM32_PROTOCOL_CONFIG_H
#define config_devicename "wzq"
#define config_deviceid "1"



#endif //STM32_PROTOCOL_CONFIG_H
